numbers = [1, 2, 3, 4, 5]

# Using lambda with map
squared_numbers = list(map(lambda x: x**2, numbers))
print(squared_numbers)  # Output: [1, 4, 9, 16, 25]

# Using lambda with filter
even_numbers = list(filter(lambda x: x % 2 == 0, numbers))
print(even_numbers)  # Output: [2, 4]

# Using lambda to calculate the sum of two numbers
add = lambda x, y: x + y
result = add(3, 5)
print(result)  # Output: 8

students = [('Alice', 25), ('Bob', 20), ('Charlie', 22)]

# Sorting based on the second element (age)
sorted_students = sorted(students, key=lambda x: x[1])
print(sorted_students)
# Output: [('Bob', 20), ('Charlie', 22), ('Alice', 25)]

# Using lambda to define a function inline
result = (lambda x: x * 2)(5)
print(result)  # Output: 10
