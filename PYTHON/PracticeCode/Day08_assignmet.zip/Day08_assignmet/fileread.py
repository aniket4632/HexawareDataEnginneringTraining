file = open('file.txt','r')
for each in file:
    print (each)

file = open('file.txt','r')
print(file.read())

with open("file.txt") as file:
    data=file.read()
print(data)

file = open('file.txt','r')
print(file.read(5))

with open('file.txt','r') as file:
    data=file.readlines()
    for line in data:
        word=line.split()
        print(word)

