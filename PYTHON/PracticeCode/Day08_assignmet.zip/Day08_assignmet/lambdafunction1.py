# Regular function
def square(x):
    return x**2

# Equivalent lambda function
square_lambda = lambda x: x**2


print(square(5))
print(square_lambda(5))
