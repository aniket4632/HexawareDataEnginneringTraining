file=open("file.text","a")
file.write("I am aniket")
file.close()
