#!/usr/bin/env python
# coding: utf-8

# # Read CSV file using csv.reader

# # Import the CSV library

# In[1]:


import csv


# # Open the CSV file

# In[2]:


file = open('Desktop/username.csv')
type(file)


# # Use the csv.reader object to read the CSV file

# In[3]:


csvreader = csv.reader(file)


# # Extract the field names

# In[4]:


header = []
header = next(csvreader)
header


# # Extract the rows/records

# In[6]:


rows = []
for row in csvreader:
    rows.append(row)
rows


# # Close the file

# In[7]:


file.close()


# # read CSV Files in python Using .readlines()

# In[9]:


with open('Desktop/username.csv') as file:
    data = file.readlines()
header = data[:1]
rows = data[1:]
print(header)
print(rows)


# # Read CSV Files in python Using Pandas

# In[10]:


import pandas as pd


# In[11]:


data= pd.read_csv("Desktop/username.csv")
data


# # Extract the field names
# 

# In[12]:


data.columns


# # Extract the rows
# 

# In[14]:


data.Username


# # Read CSV Files in python Using Pandas

# # . Import pandas library

# In[15]:


import pandas as pd


# In[16]:


data= pd.read_csv("Desktop/Sample100.csv")
data


# # Extract the field names

# In[17]:


data.columns


# # Extract the rows
# 

# In[18]:


data.Description


# # Read CSV file in python using csv.DictReader

# # Import the csv module

# In[19]:


import csv


# # Open the CSV file using the .open() function with the mode set to ‘r’ for reading.

# In[24]:


with open('Desktop/Sample100.csv', 'r') as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        print(row)


# In[ ]:





# In[ ]:




