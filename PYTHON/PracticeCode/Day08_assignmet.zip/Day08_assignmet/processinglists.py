my_list = [1, 2, 3, 4, 5]

# Accessing elements by index
print(my_list[0])

# Slicing a list
print(my_list[1:4])

# Modifying elements by index
my_list[2] = 10

# Appending elements
my_list.append(6)

# Extending a list
my_list.extend([7, 8, 9])

print(my_list)

# Removing elements by value
my_list.remove(4)

# Removing elements by index
del my_list[2]

print(my_list)

for item in my_list:
    print(item)

# Creating a new list using a list comprehension
squared_numbers = [x**2 for x in my_list]

print(squared_numbers)

# Checking if an element is in the list
print(5 in my_list)  # Output: True
print(10 in my_list)  # Output: False

# Sorting a list
my_list.sort()

# Sorting in reverse
my_list.sort(reverse=True)

print(my_list)
