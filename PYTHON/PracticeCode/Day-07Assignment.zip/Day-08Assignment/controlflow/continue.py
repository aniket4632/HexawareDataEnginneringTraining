fruits = ['apple', 'banana', 'cherry', 'date']

for fruit in fruits:
    if fruit == 'cherry':
        print('Skipping cherry.')
        continue
    print(fruit)

count = 0

while count < 5:
    count += 1
    if count == 2:
        print('Skipping count 2.')
        continue
    print(count)
