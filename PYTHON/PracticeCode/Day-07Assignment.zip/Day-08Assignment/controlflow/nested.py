for i in range(3):
    for j in range(2):
        print(i, j)
