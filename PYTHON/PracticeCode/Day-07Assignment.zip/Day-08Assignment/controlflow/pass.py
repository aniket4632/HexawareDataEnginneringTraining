while True:
    pass

for item in my_list:
    pass

def my_function():
    pass

if condition:
    pass
