a=10
b=12
if(a>b):
    print("a is greater than b")
elif (a<b):
    print("a is smaller than b")
else :
    print("a is equal to b")