a=10
b=15
if(a>b):
    print("a is greater than b")
print("a is smaller than b")



