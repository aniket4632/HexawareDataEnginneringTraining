count = 0
while (count < 3):
    count = count + 1
    print("Aniket")

i = 0
while i < 4:
    i += 1
    print(i)
else:
    print("While loop")