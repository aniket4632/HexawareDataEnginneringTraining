fruits = ['apple', 'banana', 'cherry']

for fruit in fruits:
    print(fruit)

for i in range(1, 6):
    print(i)

s = "Aniket"
for i in s:
    print(i)

for i in range(0, 10, 2):
	print(i)
