fruits = ['apple', 'banana', 'cherry', 'date']

for fruit in fruits:
    if fruit == 'cherry':
        print('Found the cherry! Exiting the loop.')
        break
    print(fruit)

count = 0

while count < 5:
    print(count)
    if count == 2:
        print('Count is 2. Breaking out of the loop.')
        break
    count += 1
