from datetime import datetime

current_datetime = datetime.now()
print(current_datetime)

formatted_date = current_datetime.strftime("%Y-%m-%d %H:%M:%S")
print(formatted_date)

date_string = "2022-01-31 14:30:00"
parsed_datetime = datetime.strptime(date_string, "%Y-%m-%d %H:%M:%S")
print(parsed_datetime)

from datetime import timedelta

one_day = timedelta(days=1)
tomorrow = current_datetime + one_day
print(tomorrow)

print(current_datetime.year)
print(current_datetime.month)
print(current_datetime.day)
