num_str = "42"
num_int = int(num_str)
num_float = float(num_str)

print(num_int)
print(num_float)

num = -5
abs_num = abs(num)
print(abs_num)

num = 3.14159
rounded_num = round(num, 2)
print(rounded_num)

numbers = [1, 5, 2, 8, 3]
max_value = max(numbers)
min_value = min(numbers)

print(max_value)
print(min_value)

numbers = [1, 2, 3, 4, 5]
sum_values = sum(numbers)
print(sum_values)

result_pow = pow(2, 3)
print(result_pow)

from math import sqrt

result_sqrt = sqrt(25)
print(result_sqrt)

from math import log

result_log = log(10)
print(result_log)

from random import randint

random_num = randint(1, 10)
print(random_num)