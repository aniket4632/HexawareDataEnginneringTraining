
#Anonymous Functions in Python

cube1=lambda x: x*x*x
print(cube1(5))

def swap(x, y):
	temp = x
	x = y
	y = temp

x = 2
y = 3
swap(x, y)
print(x)
print(y)