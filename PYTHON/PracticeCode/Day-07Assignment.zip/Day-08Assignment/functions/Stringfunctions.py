my_string = "Hello, World!"

print(len(my_string))

my_string = "Hello, World!"
new_string = my_string.capitalize()
print(new_string)

number = 42
string_number = str(number)
print(string_number)

char = 'A'

code_point = ord(char)
print(code_point)

new_char = chr(code_point)
print(new_char)

my_string = "Hello, World!"
upper_string = my_string.upper()
lower_string = my_string.lower()

print(upper_string)
print(lower_string)

my_string = "   Hello, World!   "
stripped_string = my_string.strip()

print(stripped_string)

my_string = "Hello, Python!"
new_string = my_string.replace("Python", "World")
print(new_string)

my_string = "Hello, World!"
index = my_string.find("World")
print(index)

my_string = "apple,banana,orange"
fruits_list = my_string.split(",")
print(fruits_list)

fruits_list = ['apple', 'banana', 'orange']
joined_string = ",".join(fruits_list)
print(joined_string)