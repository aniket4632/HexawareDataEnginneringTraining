'''yeild and generatiom function
n Python, we can create a generator function by simply using the def keyword and the yield keyword. 
'''
# A generator function that yields 1 for first time, 
# 2 second time and 3 third time 
def simpleGeneratorFun(): 
	yield 1			
	yield 2			
	yield 3			

# Driver code to check above generator function 
for value in simpleGeneratorFun(): 
	print(value)
x=simpleGeneratorFun()
print(next(x))
print(next(x))
print(next(x))
# This function modifies the global variable 's'
def f():
	global s
	s += ' GFG'

	print(s) 

# Global Scope
s = "Python is great!"
f()
print(s)



arr = [10, 20, 30]


def fun():
	global arr
	arr = [20, 30, 40]


print("'arr' list before executing fun():", arr)
fun()
print("'arr' list after executing fun():", arr)

'''
First Class functions in Python
1. Functions are objects:'''
def ani(n):
	return n*n
biyani=ani

print(ani(5))	
print(biyani(6))
'''2. Functions can be passed as arguments to other functions: Because functions are objects we can pass them as arguments to other functions.
Functions that can accept other functions as arguments are also called higher-order functions.'''
def sqaure(n):
	return n*n
def cube(n):
	return n*n*n
def number(n1):
	number=n1
	print(number)

number(cube(5))
'''Functions can return another function'''
def add(n):
	def adder(n1):
		return n+n1
	
	return adder
add1=add(5)
print(add1(10))
