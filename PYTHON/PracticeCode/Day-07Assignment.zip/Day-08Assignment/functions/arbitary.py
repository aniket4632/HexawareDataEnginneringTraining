'''Arbitrary Keyword  Arguments'''
'''*args in Python (Non-Keyword Arguments)
**kwargs in Python (Keyword Arguments)'''


def myFun(*argv):
    for arg in argv:
        print(arg)


myFun('Hello', 'Welcome', 'to', 'GeeksforGeeks')


def myname(**kwargs):
    for key, value in kwargs.items():
        print("%s == %s" % (key, value))


myname(first="aniket", middle="sanjaykumar", last="biyani")