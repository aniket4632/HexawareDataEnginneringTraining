'''Keyword Arguments'''
# Python program to demonstrate Keyword Arguments
def student(firstname, lastname):
	print(firstname, lastname)


# Keyword arguments
student(firstname='Aniket', lastname='Biyani')
student(lastname='Biyani', firstname='Aniket')