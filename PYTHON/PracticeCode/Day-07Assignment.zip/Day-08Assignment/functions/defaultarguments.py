'''Types of Python Function Arguments'''

'''Default argument'''
def myFun(x=30, y=40):
    print("x: ", x)
    print("y: ", y)
myFun(20)   






