
Dict = {}
print("Empty Dictionary: ")
print(Dict)

Dict = {1: 'Aniket', 2: 'abhi', 3: 'adi'}
print("\nDictionary with the use of Integer Keys: ")
print(Dict)
Dict = {'Name': 'Aniket', 1: [1, 2, 3, 4]}
print("\nDictionary with the use of Mixed Keys: ")
print(Dict)

Dict = dict({1: 'Aniket', 2: 'Sanjay', 3: 'Biyani'})
print("\nDictionary with the use of dict(): ")
print(Dict)

Dict = dict([(1, 'Aniket'), (2, 'Biyani')])
print("\nDictionary with each item as a pair: ")
print(Dict)
