Tuple1 = ()
print("Initial empty Tuple: ")
print(Tuple1)

Tuple1 = ('Aniket', 'Biyani')
print("\nTuple with the use of String: ")
print(Tuple1)

list1 = [1, 2, 4, 5, 6]
print("\nTuple using List: ")
print(tuple(list1))

Tuple1 = tuple('Aniket')
print("\nTuple with the use of function: ")
print(Tuple1)

Tuple1 = (0, 1, 2, 3)
Tuple2 = ('python', 'sql')
Tuple3 = (Tuple1, Tuple2)
print("\nTuple with nested tuples: ")
print(Tuple3)
