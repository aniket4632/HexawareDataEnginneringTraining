
#Creating list in python 
List=[]
print("Blank list is ",List)
List1=[20,30,40,50]
print("The values in list are",List1)

#accesing the list
print(List1[0])
print(List1[1])

#multiple distinct values
List2=[1,2,3,4,2,2,2,4,5,6]
print("The values in multiple distinct list are",List2)

#mixed values
List3=[1,"Aniket","Biyani",2.0,"Anix"]
print("Mixed values are",List3)

#Accessing elements from a multi-dimensional list
List4=[['Aniket','Biyani'],['Latur']]
print("Multi elements accesing",List4[0][0],List4[0][1],List4[1])

#Size of a List
print("Size of a list is",len(List4))

#Splitting and adding string to list
str=input("Enter the string name")
l=str.split()
print(l)

#Adding elements to list using append
List=[]
List.append(1)
List.append(2)
List.append(3)
List.insert(0,0)
List.extend([4,5,6])
print(List)

#Reversing a List
list=[1,2,3,4,5]
list.reverse()
print(list)
list5=[1,2,3,4,5]
rev_list=list(reversed(list5))
print(rev_list)

#Deleting a list
List6=[1,2,3,4,5,6,6]
List6.remove(6)
List6.pop(0)
print(List6)