str="aniket Biyani"
print(str[12])

print(str[-1])

#Slicing
print(str[3:12])
print(str[3:-2])
#reversing
print(str[::-1])
print("".join(reversed(str)))
list1=list(str)
list1[0]='A'
str2=''.join(list1)
print(str2)
str3=str[0:6]+str[7:]
print(str3)
del str3


