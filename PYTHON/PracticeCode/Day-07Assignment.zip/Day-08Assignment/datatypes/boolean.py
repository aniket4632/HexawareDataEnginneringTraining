print(type(True))
print(type(False))


