p = True
q = False

print(p and q)
print(p or q)
print(not q)