#Bitwise operators

a=10
b=4
print(a&b)
print(a|b)
print(a^b)
print(~b)
print(a>>b)
print(a<<b)
