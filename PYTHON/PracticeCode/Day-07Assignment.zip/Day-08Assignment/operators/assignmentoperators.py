
# Assign opeartors

a = 3
b = 5

c = a + b
print(c)
a+=b
print(a)
a-=b
print(a)
a*=b
print(a)
a/=b
print(a)
a%=b
print(a)
a//=b
print(a)
a**=b
print(a)