import operator
a=5
b=3
print(operator.add(a,b))
print(operator.sub(a,b))
print(operator.mul(a,b))
print(operator.truediv(a,b))
print(operator.floordiv(a,b))
print(operator.pow(a,b))
print(operator.mod(a,b))
print(operator.lt(a,b))
print(operator.le(a,b))
print(operator.eq(a,b))
print(operator.gt(a,b))
print(operator.ge(a,b))
print(operator.ne(a,b))

import operator 
li = [1, 5, 6, 7, 8]
operator.setitem(li,3,3) 
operator.delitem(li,1) 

for i in range(0,len(li)):
    print(li[i],end=" ")
print("\r")
print(operator.getitem(li,3))

import operator
a="biyaniket"
b="aniket"
print(operator.concat(a,b))
if(operator.contains(a,b)):
    print("biyaniket contains aniket")
else : print("doesnot contains")

str1="aniket"
str2="aniket"
if(str1==str2):
    print("true")
else:
    print("False")
if(str1 is str2):
    print("true")
else:
    print("False")