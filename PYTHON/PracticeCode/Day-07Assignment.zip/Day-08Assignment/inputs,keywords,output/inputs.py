num=input("Enter phone number")

name=input("Enter the name")
print("Your name is ",name , "and number is ",num)
print(type(num))
print(type(name))

num=int(input("Enter phone number"))

name=input("Enter the name")
print("Your name is ",name , "and number is ",num)
print(type(num))
print(type(name))
