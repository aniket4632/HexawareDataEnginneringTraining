#print("Geeks : %d, Portal : %.2f" % (1, 05.333)) 
 
#print("Total students : %2d, Boys : %d" % (240, 120))   # print integer value
 
#print("%.8o" % (25))   # print octal value
 
print("%.9E" % (356.08977))