#Using split() method
x,y=input("Enter the values").split()
print(x)
print(y)
print("First number is{}and sexond number is {}".format(x,y))

z=list(map(int,input("Enter the values").split()))
print(z)

#using list comprehension
x = [int(x) for x in input("Enter multiple values: ").split()]
print("Number of list is: ", x) 