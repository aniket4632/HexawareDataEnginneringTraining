# Using “\”(Explicit line continuation)
name={"aniket\
      sanjaykumar\
      biyani"}
print(name)

#Using parenthesis (Implicit line continuation):
name={f"aniket"
      f"biyani"}
print(name)

#Using triple quote(line break)
g = """geeks
for
geeks"""
print(g)

"""This article on geeksforgeeks gives you a 
perfect example of
multi-line comments"""
 
print("GeeksForGeeks")
"""
Docstrings are written in the functions and classes to show how to use the program.
Multi-line comments are used to show how a block of code works.

"""