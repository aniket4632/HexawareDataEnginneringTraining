
import keyword
print(keyword.kwlist)