'''
write a Python program to find the sum of all the elements in the list.

Example:  

Input: [12, 15, 3, 10]
Output: 40

Input: [17, 5, 3, 5]
Output: 30
#2 print the value obtained after multiplying all numbers in a Python list. 

Examples: 

Input :  list1 = [1, 2, 3] 
Output : 6 
Explanation: 1*2*3=6 

Input : list1 = [3, 2, 4] 
Output : 24 

#3
Python program to find smallest number in a list
Input : list1 = [10, 20, 4]
Output : 4

Input : list2 = [20, 10, 20, 1, 100]
Output : 1

#4
write a Python program to find the largest number in given list. 

Examples:

Input : list1 = [10, 20, 4]
Output : 20

#5
write a Python program to find the second largest number in the given list.

Examples: 

Input: list1 = [10, 20, 4]
Output: 10

Input: list2 = [70, 11, 20, 4, 100]
Output: 70

'''
def sum(list):
    total=0
    for i in range(0,len(list)):
        total=total+list[i]
    return total  
def mul(list):
    total=1
    for i in range(0,len(list)):
        total=total*list[i]
    return total    
def sortsmall(list):
    list.sort()
    return ("Smallest number is",list[0])
def sortlarge(list):
    list.sort()
    return ("largest number is",list[len(list)-1])
def secondlarge(list):
    list.sort()
    return ("Second largest number is",list[len(list)-2])


list=[]
n=int(input("Enter the number of elements"))
for i in range(0,n):
    ele=int(input())
    list.append(ele)
print(list)
print(sum(list))
print(mul(list))
print(sortsmall(list))
print(sortlarge(list))
print(secondlarge(list))
