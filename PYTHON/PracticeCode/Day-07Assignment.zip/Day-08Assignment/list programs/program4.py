'''
write a program to swap the two elements in the list. 

Examples:  

Input : List = [23, 65, 19, 90], pos1 = 1, pos2 = 3
Output : [19, 65, 23, 90]

Input : List = [1, 2, 3, 4, 5], pos1 = 2, pos2 = 5
Output : [1, 5, 3, 4, 2]'''
def swap_list(list,pos1,pos2):
    n1=len(list)
    temp=list[pos1-1]
    list[pos1-1]=list[pos2-1]
    list[pos2-1]=temp
    return list  
list=[]
n=int(input("Enter the number of elements "))
for i in range(0,n):
    ele=int(input())
    list.append(ele)
print(list)
pos1=int(input("Enter the position 1 "))
pos2=int(input("Enter the position 2 "))

print(swap_list(list,pos1,pos2))