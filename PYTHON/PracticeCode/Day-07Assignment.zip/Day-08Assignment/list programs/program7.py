'''
write a Python program to print all even numbers in the given list.

Example: 

Input: list1 = [2, 7, 5, 64, 14]
Output: [2, 64, 14]
Input: list2 = [12, 14, 95, 3]
Output: [12, 14]

#2
write a Python program to print all odd numbers in the given list. 

Example:

Input: list1 = [2, 7, 5, 64, 14]
Output: [7, 5]

Input: list2 = [12, 14, 95, 3, 73]
Output: [95, 3, 73]
'''
def evennumber(list):
    list1=[]
    for i in list:
        if(i%2==0):
           list1.append(i)
    return list1   
def oddnumber(list):
    list2=[]
    for i in list:
        if(i%2!=0):
           list2.append(i)
    return list2  



list=[]
n=int(input("Enter the number of elements"))
for i in range(0,n):
    ele=int(input())
    list.append(ele)
print(list)
print(evennumber(list))
print(oddnumber(list))