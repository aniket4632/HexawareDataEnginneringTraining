'''
Given two numbers r1 and r2 (which defines the range), write a Python program to create a list with the
 given range (inclusive). 

Examples:

Input : r1 = -1, r2 = 1
Output : [-1, 0, 1]

Input : r1 = 5, r2 = 9
Output : [5, 6, 7, 8, 9]'''
def  listt(r1,r2):
    list=[]
    for i in range(r1,r2+1):
        list.append(i)
    return list    
r1=int(input("Enter the range 1 "))
r2=int(input("Enter the range 2 "))
print(listt(r1,r2))

