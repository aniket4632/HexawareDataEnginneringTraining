'''
#6
the task is to find N largest elements assuming size of list is greater than or equal o N. 

Examples :
Input : [4, 5, 1, 2, 9] 
        N = 2
Output :  [9, 5]

Input : [81, 52, 45, 10, 3, 2, 96] 
        N = 3
Output : [81, 96, 52]
'''
def nlarge(list,n1):
    list.sort() 
    print(list)
    return(list[-n1::])

list=[]
n=int(input("Enter the number of elements"))
for i in range(0,n):
    ele=int(input())
    list.append(ele)
print(list)
n1=int(input("Enter the n1 large elements"))
print(nlarge(list,n1))