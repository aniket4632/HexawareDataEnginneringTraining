'''
write a Python program to print all even numbers in that given range. 

Example:

Input: start = 4, end = 15
Output: 4, 6, 8, 10, 12, 14

Input: start = 8, end = 11
Output: 8, 10
#2
write a Python program to print all odd numbers in that given range. 

Example:

Input: start = 4, end = 15
Output: 5, 7, 9, 11, 13, 15

Input: start = 3, end = 11
Output: 3, 5, 7, 9, 11'''
def evennumber(range1,range2):
    list=[]
    for i in range(range1,range2+1) :
        if(i%2==0):
           list.append(i)
    return list  
def oddnumber(range1,range2):
    list1=[]
    for i in range(range1,range2+1) :
        if(i%2!=0):
           list1.append(i)
    return list1   


range1=int(input("Enter the range1 "))
range2=int(input("Enter the range2 "))
print(evennumber(range1,range2))
print(oddnumber(range1,range2))