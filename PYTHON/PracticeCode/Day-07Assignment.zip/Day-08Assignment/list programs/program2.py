'''
Accessing index and value in list Using Naive method
'''
list1=[3,4,5,6]
print("Original list is ",list)
print("Index values are: ")
for i in range(len(list1)):
    print(i,end=" ")
    print(list1[i])
print("Using list comprehension")
print([list((i,list1[i])) for i in range(len(list1))])