'''
Python Program for How to check if a given number is Fibonacci number?
Input: 8
Output: Yes

Input: 34
Output: Yes

Input: 41
Output: No
'''
import math 

def isPerfectsquare(x):
    s=int(math.sqrt(x))
    return s*s==x
def isfibonacci(n):
    return isPerfectsquare(5*n*n+4) or isPerfectsquare(5*n*n-4)

n=int(input("Enter the fibonacci number"))
print(isfibonacci(n))