'''
Given two numbers, write a Python code to find the Maximum of these two numbers.

Examples: 

Input: a = 2, b = 4
Output: 4

Input: a = -1, b = -4
Output: -1
'''
def max(a,b):
    if(a>b):
        return a
    else:
        return b
a=int(input("Enter the value "))
b=int(input("Enter the value "))
print("Maximum among a and b is",max(a,b))