'''
write a Python program to check if the number is Prime or not in Python.

Examples: 

Input:  n = 11
Output: True


Input:  n = 1
Output: False
'''
def isprime(n):
    if(n<=1):
        return "Not a prime number"
    else:
        for i in range(2,int(n/2)+1):
            if(n%i==0):
                return "Not a prime number"                
        return "Prime number"
n=int(input("Enter the number"))
print(isprime(n))