'''
Given a number x, determine whether the given number is Armstrong number or not. A positive integer of
 n digits is called an Armstrong number of order n (order is number of digits) if.

Input : 153
Output : Yes
153 is an Armstrong number.
1*1*1 + 5*5*5 + 3*3*3 = 153

Input : 120
Output : No
120 is not a Armstrong number.
1*1*1 + 2*2*2 + 0*0*0 = 9'''

def isArmstrong(num):
    num1=num
    sum=0
    while num1!=0:
        r=num1 % 10
        sum=sum+(r*r*r)
        num1=num1//10
    if num==sum:
        return ("Its armstrong number")        
    else:
        return ("Its not armstrong number")
num=int(input("Enter the number"))
print(isArmstrong(num))
