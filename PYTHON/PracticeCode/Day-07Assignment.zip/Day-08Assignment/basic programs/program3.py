'''
Factorial of a number
'''
def factorial(a):
    if a<0:
        return 0
    elif a == 1 or a == 0:
        return 1
    else:
        fact=1
        while(a>1):
            fact=fact*a
            a-=1
        return fact

a=int(input("Enter the number"))
print("Factorial of a is ",factorial(a))