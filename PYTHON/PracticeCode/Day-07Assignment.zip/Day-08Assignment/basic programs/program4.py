'''
Simple interest formula is given by: Simple Interest = (P x T x R)/100 Where, P is the principal amount T is the time and R is the rate

Examples:

Input : P = 10000
        R = 5
        T = 5
Output :2500.0
We need to find simple interest on 
Rs. 10,000 at the rate of 5% for 5 
units of time.'''
def simpleinterest(P,T,R):
    return (P*T*R)/100
P=int(input("Enter the principal amount"))
T=int(input("Enter the time "))
R=int(input("Enter the rate of interest"))
print("Simple interest would be ",simpleinterest(P,T,R))