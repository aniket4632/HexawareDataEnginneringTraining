'''Given two numbers num1 and num2. The task is to write a Python program to find the addition
 of these two numbers. 

Examples:

Input: num1 = 5, num2 = 3
Output: 8
Input: num1 = 13, num2 = 6
Output: 19'''
#1
'''
num1=int(input("Enter the num1 value"))
num2=int(input("Enter the num2 value"))
print(num1+num2)
'''
#2
def add(num1,num2):
    return num1+num2
num1=int(input("Enter the num1 value "))
num2=int(input("Enter the num2 value "))
print(add(num1,num2))