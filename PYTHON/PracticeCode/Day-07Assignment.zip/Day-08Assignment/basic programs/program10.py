'''
Program to print ASCII Value of a character
Input : a 
Output : 97

Input : D
Output : 68
'''
charascii=input("Enter the value of character :")
print("the ascii value is",ord(charascii))

