
class calculator:
    first=0
    second=0
    answer=0
    def __init__(self,f,s):
        self.first=first
        self.second=second
    def calculate(self):
        self.answer=self.first + self.second
    def display(self):
        print("First Number = "+str(self.first))
        print("Second Number = "+str(self.second))
        print("additon of number is = "+str(self.answer))



first=int(input("Enter the first number"))
second=int(input("Enter the second number"))
obj1=calculator(first,second)
obj1.calculate()
obj1.display()

