try:
    number = int(input("Enter a number: "))
    result = 10 / number

except ValueError:
    print("Invalid input. Please enter a valid number.")

except ZeroDivisionError:
    print("Cannot divide by zero.")

else:
    print(f"The result is: {result}")

finally:
    print("Cleanup code: This code always runs.")
