class Animal:
    def __init__(self, species):
        self.species = species

    def make_sound(self):
        print("Generic animal sound")

class Dog(Animal):
    def __init__(self, name, age):
        super().__init__("Dog")
        self.name = name
        self.age = age

    def bark(self):
        print(f"{self.name} says Woof!")

dog = Dog("Buddy", 3)


dog.make_sound()
