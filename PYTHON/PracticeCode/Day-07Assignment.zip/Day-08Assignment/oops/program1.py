'''Class
Objects
Polymorphism
Encapsulation
Inheritance
Data Abstraction'''
class Company:
    field="software"
    def __init__(self,name):
        self.name=name
    def __init__(self,name1):
        self.name1=name1
Company1=Company("Hexaware")
Company2=Company("Nvidia")
print("Field of company is {}".format(Company1.__class__.field))        
print("Name of company1 is {} ".format(Company1.name1))

print("Name of company1 is {} ".format(Company2.name1))

class Aniket:
    pass
obj = Aniket()
 


