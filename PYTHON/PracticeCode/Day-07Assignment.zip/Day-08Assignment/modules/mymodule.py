from math import sqrt, factorial

print(sqrt(16))
print(factorial(6))

import sys

print(sys.path)

import math as mt

print(mt.sqrt(16))
print(mt.factorial(6))


from datetime import date
import time

print(time.time())

print(date.fromtimestamp(454554))