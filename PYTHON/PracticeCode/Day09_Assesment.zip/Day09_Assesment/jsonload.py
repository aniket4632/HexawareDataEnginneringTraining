import json


json_string = '{"name": "John", "age": 30, "city": "New York"}'


python_dict = json.loads(json_string)

print("Python dictionary:", python_dict)

import json

nested_json_string = '''
{
  "name": "John",
  "age": 30,
  "address": {
    "city": "New York",
    "zip": "10001"
  }
}
'''

nested_python_dict = json.loads(nested_json_string)


print("Nested Python dictionary:", nested_python_dict)

import json

json_string = '{"name": "John", "age": 30, "city": "New York"}'

#
python_dict = json.loads(json_string)

print("Python dictionary:", python_dict)
