import json

json_file_path = 'data.json'


with open(json_file_path, 'r') as json_file:
    python_dict = json.load(json_file)


print("Python dictionary:", python_dict)
