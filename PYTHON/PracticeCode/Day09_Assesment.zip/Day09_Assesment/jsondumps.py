import json


python_dict = {"name": "John", "age": 30, "city": "New York"}

json_string = json.dumps(python_dict)


print("JSON string:", json_string)

import json

python_dict = {"name": "John", "age": 30, "city": "New York"}

json_file_path = 'data.json'

with open(json_file_path, 'w') as json_file:
    json.dump(python_dict, json_file)

print(f"Python dictionary written to {json_file_path}")

import json

python_dict = {
    "name": "John",
    "age": 30,
    "city": "New York",
    "skills": ["Python", "JavaScript", "SQL"]
}

pretty_json_string = json.dumps(python_dict, indent=2)


print("Pretty-printed JSON:")
print(pretty_json_string)

