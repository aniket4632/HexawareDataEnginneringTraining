
my_list = ["apple", "banana", "kiwi", "orange", "grape"]


sorted_list = sorted(my_list, key=len)

print("Original list:", my_list)
print("Sorted list based on string lengths:", sorted_list)


my_list_of_tuples = [(1, 4), (3, 2), (5, 1), (2, 3), (4, 5)]


sorted_tuples = sorted(my_list_of_tuples, key=lambda x: x[1])

print("Original list of tuples:", my_list_of_tuples)
print("Sorted list of tuples based on the second element:", sorted_tuples)

