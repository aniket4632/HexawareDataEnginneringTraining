#using set

my_list = [1, 2, 3, 1, 2, 4, 5, 6, 4]

# Use set() to get unique values
unique_values = set(my_list)

# Convert the set back to a list if needed
unique_list = list(unique_values)


print("Original list:", my_list)
print("Unique values:", unique_list)

#using reduce

from functools import reduce

my_list = [1, 2, 3, 1, 2, 4, 5, 6, 4]


unique_values = reduce(lambda x, y: x + [y] if y not in x else x, my_list, [])


print("Original list:", my_list)
print("Unique values:", unique_values)


my_list = [1, 2, 3, 1, 2, 4, 5, 6, 4]

unique_values = list(dict.fromkeys(my_list))


print("Original list:", my_list)
print("Unique values:", unique_values)


from collections import Counter


my_list = [1, 2, 3, 1, 2, 4, 5, 6, 4]


unique_values = list(Counter(my_list).keys())

# Print the results
print("Original list:", my_list)
print("Unique values:", unique_values)



my_list = [1, 2, 3, 1, 2, 4, 5, 6, 4]


unique_values = set(map(lambda x: x, my_list))

unique_list = list(unique_values)

print("Original list:", my_list)
print("Unique values:", unique_list)
